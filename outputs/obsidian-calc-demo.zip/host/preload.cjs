"use strict";

// packages/desktop-host/src/preload.ts
var import_electron = require("electron");
import_electron.contextBridge.exposeInMainWorld("splice", Object.freeze({
  workflows: () => import_electron.ipcRenderer.invoke("splice:workflows"),
  runWorkflow: (workflowId, input) => import_electron.ipcRenderer.invoke("splice:run", workflowId, input),
  getDocument: (documentId) => import_electron.ipcRenderer.invoke("splice:document", documentId),
  saveDocument: (documentId, value, expectedRevision) => import_electron.ipcRenderer.invoke("splice:document-save", documentId, value, expectedRevision),
  transcriptionAvailability: () => import_electron.ipcRenderer.invoke("splice:transcription-availability"),
  listTranscriptions: () => import_electron.ipcRenderer.invoke("splice:transcriptions"),
  getTranscription: (sessionId) => import_electron.ipcRenderer.invoke("splice:transcription", sessionId),
  startTranscription: (bytes, providerId, language) => import_electron.ipcRenderer.invoke("splice:transcription-start", bytes, providerId, language),
  cancelTranscription: (sessionId) => import_electron.ipcRenderer.invoke("splice:transcription-cancel", sessionId),
  onTranscription: (callback) => {
    const listener = (_event, session) => callback(session);
    import_electron.ipcRenderer.on("splice:transcription-event", listener);
    return () => import_electron.ipcRenderer.removeListener("splice:transcription-event", listener);
  }
}));
