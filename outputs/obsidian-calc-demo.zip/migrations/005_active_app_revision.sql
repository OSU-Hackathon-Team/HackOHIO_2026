CREATE TABLE IF NOT EXISTS app_active_revisions (
  app_id TEXT PRIMARY KEY,
  revision INTEGER NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (app_id, revision) REFERENCES apps (app_id, revision)
);
INSERT INTO app_active_revisions (app_id, revision, updated_at)
SELECT app_id, MAX(revision), strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
FROM apps WHERE status = 'verified' GROUP BY app_id;