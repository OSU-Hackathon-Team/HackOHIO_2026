CREATE TABLE IF NOT EXISTS documents (
  document TEXT PRIMARY KEY,
  revision INTEGER NOT NULL CHECK (revision >= 1),
  data TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS apps (
  app_id TEXT NOT NULL,
  revision INTEGER NOT NULL CHECK (revision >= 0),
  title TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('verified', 'failed')),
  app_hash TEXT NOT NULL,
  bundle TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY (app_id, revision)
);
CREATE TABLE IF NOT EXISTS outbox (
  id TEXT PRIMARY KEY,
  topic TEXT NOT NULL,
  payload TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending', 'delivered', 'failed')),
  attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS jobs (
  job_id TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  status TEXT NOT NULL,
  progress TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  result_ref TEXT,
  error TEXT,
  request_hash TEXT NOT NULL
);