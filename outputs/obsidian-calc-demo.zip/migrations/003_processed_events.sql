CREATE TABLE IF NOT EXISTS processed_events (
  scope TEXT NOT NULL,
  event_key TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY (scope, event_key)
);