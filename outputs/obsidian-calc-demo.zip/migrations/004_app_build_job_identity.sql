ALTER TABLE apps ADD COLUMN build_job_id TEXT;
CREATE UNIQUE INDEX idx_apps_build_job ON apps (build_job_id) WHERE build_job_id IS NOT NULL;