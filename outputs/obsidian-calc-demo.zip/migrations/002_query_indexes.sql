CREATE INDEX IF NOT EXISTS idx_apps_latest ON apps (app_id, revision DESC);
CREATE INDEX IF NOT EXISTS idx_apps_status ON apps (app_id, status, revision DESC);
CREATE INDEX IF NOT EXISTS idx_outbox_pending ON outbox (status, created_at, id);
CREATE INDEX IF NOT EXISTS idx_documents_updated ON documents (updated_at);