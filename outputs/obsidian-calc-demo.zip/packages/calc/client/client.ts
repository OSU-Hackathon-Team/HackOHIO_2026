// Generated from CapabilityDefinition splice.calc.tables@1.0.0.
import type { CapabilityClient } from "@splice/runtime";
export type EvaluateRequest = { "formula": string; "cells": Record<string, number> };
export type EvaluateResult = { "value": number };
export type EvaluateError = { "code": "invalid_input" | "internal"; "message": string };
export type TableOperationRequest = { "operation": { "type": "sort_range" | "insert_rows" | "delete_rows" | "insert_columns" | "delete_columns"; "range"?: string; "keys"?: Array<{ "column": number; "ascending": boolean }>; "contains_header"?: boolean; "index"?: number; "count"?: number; "output_range"?: string }; "cells": Record<string, string> };
export type TableOperationResult = { "cells": Array<Array<string>> };
export type TableOperationError = { "code": "invalid_input" | "internal"; "message": string };
export interface SpliceCalcTablesClient { evaluate(input: EvaluateRequest): Promise<EvaluateResult>; table_operation(input: TableOperationRequest): Promise<TableOperationResult>; }
export function createSpliceCalcTablesClient(client: CapabilityClient): SpliceCalcTablesClient {
  return { evaluate: (input: EvaluateRequest) => client.call("evaluate", input as Record<string, unknown>) as Promise<EvaluateResult>,
table_operation: (input: TableOperationRequest) => client.call("table_operation", input as Record<string, unknown>) as Promise<TableOperationResult>, };
}
