# LibreOffice Calc Table Operations and Formula Evaluator

Generated public client and host wrapper for splice.calc.tables@1.0.0.

The operation request, result, and error types come from the pinned wire schemas. Use createSpliceCalcTablesClient with a verified @splice/runtime CapabilityClient. Use dispatchSpliceCalcTablesOperation to validate both sides of a host handler.

- evaluate: Evaluate formula expression with cell references
- table_operation: Execute LibreOffice Calc table operations (sort, insert/delete rows/cols)
