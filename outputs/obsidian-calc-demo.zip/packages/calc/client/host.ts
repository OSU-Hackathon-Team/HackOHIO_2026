// Generated wire boundary for splice.calc.tables@1.0.0.
import { encodeWireValue, decodeWireValue, type WireObjectType } from "@splice/contracts";
const schemas: Record<string, { request: WireObjectType; result: WireObjectType }> = {"evaluate":{"request":{"kind":"object","fields":[{"name":"formula","type":{"kind":"string","encoding":"utf-8","max_bytes":50000},"optional":false},{"name":"cells","type":{"kind":"map","values":{"kind":"float","bits":64},"max_entries":2048},"optional":false}],"additional":false},"result":{"kind":"object","fields":[{"name":"value","type":{"kind":"float","bits":64},"optional":false}],"additional":false}},"table_operation":{"request":{"kind":"object","fields":[{"name":"operation","type":{"kind":"object","fields":[{"name":"type","type":{"kind":"enum","values":["sort_range","insert_rows","delete_rows","insert_columns","delete_columns"]},"optional":false},{"name":"range","type":{"kind":"string","encoding":"utf-8","max_bytes":50000},"optional":true},{"name":"keys","type":{"kind":"array","items":{"kind":"object","fields":[{"name":"column","type":{"kind":"int","bits":32,"signed":true},"optional":false},{"name":"ascending","type":{"kind":"bool"},"optional":false}],"additional":false},"max_items":10,"ordered":true},"optional":true},{"name":"contains_header","type":{"kind":"bool"},"optional":true},{"name":"index","type":{"kind":"int","bits":32,"signed":true},"optional":true},{"name":"count","type":{"kind":"int","bits":32,"signed":true},"optional":true},{"name":"output_range","type":{"kind":"string","encoding":"utf-8","max_bytes":50000},"optional":true}],"additional":false},"optional":false},{"name":"cells","type":{"kind":"map","values":{"kind":"string","encoding":"utf-8","max_bytes":5000},"max_entries":2048},"optional":false}],"additional":false},"result":{"kind":"object","fields":[{"name":"cells","type":{"kind":"array","items":{"kind":"array","items":{"kind":"string","encoding":"utf-8","max_bytes":50000},"max_items":100,"ordered":true},"max_items":500,"ordered":true},"optional":false}],"additional":false}}};
export async function dispatchSpliceCalcTablesOperation(
  handlers: Record<string, (input: Record<string, unknown>) => Promise<Record<string, unknown>>>,
  name: string,
  input: unknown,
): Promise<Record<string, unknown>> {
  const schema = schemas[name];
  const handler = handlers[name];
  if (!schema || !handler) throw new Error("Unknown capability operation " + name);
  const request = decodeWireValue(schema.request, encodeWireValue(schema.request, input)) as Record<string, unknown>;
  const result = await handler(request);
  return decodeWireValue(schema.result, encodeWireValue(schema.result, result)) as Record<string, unknown>;
}
