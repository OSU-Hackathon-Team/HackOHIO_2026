// Generated wire boundary for splice.obsidian.editor@1.0.0.
import { encodeWireValue, decodeWireValue, type WireObjectType } from "@splice/contracts";
const schemas: Record<string, { request: WireObjectType; result: WireObjectType }> = {"render":{"request":{"kind":"object","fields":[{"name":"markdown","type":{"kind":"string","encoding":"utf-8","max_bytes":500000},"optional":false}],"additional":false},"result":{"kind":"object","fields":[{"name":"html","type":{"kind":"string","encoding":"utf-8","max_bytes":500000},"optional":false}],"additional":false}},"edit":{"request":{"kind":"object","fields":[{"name":"doc","type":{"kind":"string","encoding":"utf-8","max_bytes":500000},"optional":false},{"name":"action","type":{"kind":"enum","values":["replace","append"]},"optional":false},{"name":"text","type":{"kind":"string","encoding":"utf-8","max_bytes":500000},"optional":false}],"additional":false},"result":{"kind":"object","fields":[{"name":"markdown","type":{"kind":"string","encoding":"utf-8","max_bytes":500000},"optional":false},{"name":"html","type":{"kind":"string","encoding":"utf-8","max_bytes":500000},"optional":false}],"additional":false}}};
export async function dispatchSpliceObsidianEditorOperation(
  handlers: Record<string, (input: Record<string, unknown>) => Promise<Record<string, unknown>>>,
  name: string,
  input: unknown,
): Promise<Record<string, unknown>> {
  const schema = schemas[name];
  const handler = handlers[name];
  if (!schema || !handler) throw new Error("Unknown capability operation " + name);
  const request = decodeWireValue(schema.request, encodeWireValue(schema.request, input)) as Record<string, unknown>;
  const result = await handler(request);
  return decodeWireValue(schema.result, encodeWireValue(schema.result, result)) as Record<string, unknown>;
}
