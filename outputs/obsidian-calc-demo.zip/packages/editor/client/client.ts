// Generated from CapabilityDefinition splice.obsidian.editor@1.0.0.
import type { CapabilityClient } from "@splice/runtime";
export type RenderRequest = { "markdown": string };
export type RenderResult = { "html": string };
export type RenderError = { "code": "invalid_input" | "internal"; "message": string };
export type EditRequest = { "doc": string; "action": "replace" | "append"; "text": string };
export type EditResult = { "markdown": string; "html": string };
export type EditError = { "code": "invalid_input" | "internal"; "message": string };
export interface SpliceObsidianEditorClient { render(input: RenderRequest): Promise<RenderResult>; edit(input: EditRequest): Promise<EditResult>; }
export function createSpliceObsidianEditorClient(client: CapabilityClient): SpliceObsidianEditorClient {
  return { render: (input: RenderRequest) => client.call("render", input as Record<string, unknown>) as Promise<RenderResult>,
edit: (input: EditRequest) => client.call("edit", input as Record<string, unknown>) as Promise<EditResult>, };
}
