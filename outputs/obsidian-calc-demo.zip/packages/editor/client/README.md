# Obsidian Markdown Editor and Renderer

Generated public client and host wrapper for splice.obsidian.editor@1.0.0.

The operation request, result, and error types come from the pinned wire schemas. Use createSpliceObsidianEditorClient with a verified @splice/runtime CapabilityClient. Use dispatchSpliceObsidianEditorOperation to validate both sides of a host handler.

- render: Render Markdown string to sanitized HTML
- edit: Apply editing action and return updated markdown and rendered HTML
