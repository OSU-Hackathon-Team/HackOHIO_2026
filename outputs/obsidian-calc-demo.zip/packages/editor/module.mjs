// index.ts
function renderMarkdown(markdown) {
  const lines = markdown.split("\n");
  let html = "";
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (line.startsWith("#")) {
      const headingMatch = line.match(/^(#{1,6})\s+(.*)$/);
      if (headingMatch) {
        const level = headingMatch[1].length;
        const content = headingMatch[2];
        html += `<h${level}>${formatInline(content)}</h${level}>
`;
        i++;
        continue;
      }
    } else if (line.startsWith("```")) {
      const langMatch = line.match(/^```(\w*)/);
      const lang = langMatch ? langMatch[1] : "";
      i++;
      let codeContent = "";
      while (i < lines.length && !lines[i].startsWith("```")) {
        codeContent += lines[i] + "\n";
        i++;
      }
      i++;
      html += `<pre><code class="${lang ? `language-${lang}` : ""}">${escapeHtml(codeContent.trim())}</code></pre>
`;
      continue;
    } else if (line.startsWith("> ")) {
      if (line.includes("[!")) {
        const calloutMatch = line.match(/> \[!(\w+)\]/);
        const calloutType = calloutMatch ? calloutMatch[1].toLowerCase() : "note";
        i++;
        let calloutContent = "";
        while (i < lines.length && lines[i].startsWith("> ")) {
          calloutContent += lines[i].substring(2) + "\n";
          i++;
        }
        html += `<div class="callout" data-callout="${calloutType}">${formatInline(calloutContent.trim())}</div>
`;
        continue;
      } else {
        let quoteContent = "";
        while (i < lines.length && lines[i].startsWith("> ")) {
          quoteContent += lines[i].substring(2) + "\n";
          i++;
        }
        html += `<blockquote>${formatInline(quoteContent.trim())}</blockquote>
`;
        continue;
      }
    } else if (line.startsWith("- ") || line.startsWith("* ")) {
      const listItems = [];
      while (i < lines.length && (lines[i].startsWith("- ") || lines[i].startsWith("* ") || lines[i].startsWith("  "))) {
        const listItemLine = lines[i];
        const indentLevel = Math.floor((listItemLine.search(/\S/) || 0) / 2);
        const content = listItemLine.trim().substring(2);
        listItems.push({ content, level: indentLevel });
        i++;
      }
      html += renderList(listItems);
      continue;
    } else if (/^\|(.+\|)+$/.test(line)) {
      const tableLines = [];
      while (i < lines.length && lines[i].trim() !== "") {
        tableLines.push(lines[i]);
        i++;
      }
      html += renderTable(tableLines);
      continue;
    } else if (line.trim() === "") {
      i++;
      continue;
    } else {
      let paragraphContent = line;
      i++;
      while (i < lines.length && lines[i].trim() !== "" && !lines[i].startsWith("#") && !lines[i].startsWith("```") && !lines[i].startsWith("> ") && !lines[i].startsWith("- ") && !lines[i].startsWith("* ") && !/^\|(.+\|)+$/.test(lines[i])) {
        paragraphContent += " " + lines[i];
        i++;
      }
      html += `<p>${formatInline(paragraphContent)}</p>
`;
      continue;
    }
    if (line.trim() !== "") {
      html += `<p>${formatInline(line)}</p>
`;
    }
    i++;
  }
  return { html: html.trim() };
}
function renderList(items) {
  if (items.length === 0) return "";
  let html = "";
  let currentLevel = -1;
  items.forEach((item, index) => {
    if (item.level > currentLevel) {
      for (let i = currentLevel; i < item.level; i++) {
        html += "<ul>\n";
      }
    } else if (item.level < currentLevel) {
      for (let i = currentLevel; i > item.level; i--) {
        html += "</li>\n</ul>\n";
      }
    } else if (index > 0) {
      html += "</li>\n";
    }
    html += `<li>${formatInline(item.content)}`;
    currentLevel = item.level;
  });
  for (let i = currentLevel; i >= 0; i--) {
    if (i === currentLevel) {
      html += "</li>\n";
    }
    html += "</ul>\n";
  }
  return html;
}
function renderTable(lines) {
  if (lines.length < 2) return "";
  const headers = lines[0].split("|").map((cell) => cell.trim()).filter((cell) => cell.length > 0);
  let html = "<table>\n<thead>\n<tr>\n";
  headers.forEach((header) => {
    html += `<th>${formatInline(header)}</th>
`;
  });
  html += "</tr>\n</thead>\n<tbody>\n";
  for (let i = 2; i < lines.length; i++) {
    const cells = lines[i].split("|").map((cell) => cell.trim()).filter((cell) => cell.length > 0);
    if (cells.length > 0) {
      html += "<tr>\n";
      cells.forEach((cell) => {
        html += `<td>${formatInline(cell)}</td>
`;
      });
      html += "</tr>\n";
    }
  }
  html += "</tbody>\n</table>\n";
  return html;
}
function formatInline(text) {
  if (!text) return "";
  text = text.replace(/\[\[(.*?)\]\]/g, '<a class="internal-link" data-href="$1" href="$1">$1</a>');
  text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a class="external-link" href="$2" rel="noopener nofollow">$1</a>');
  text = text.replace(/~~(.*?)~~/g, "<del>$1</del>");
  text = text.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
  text = text.replace(/__(.*?)__/g, "<strong>$1</strong>");
  text = text.replace(/(?<!\*)\*(?!\*)(.*?)\*(?!\*)/g, "<em>$1</em>");
  text = text.replace(/(?<!_)_(?!_)(.*?)_(?!_)/g, "<em>$1</em>");
  return text;
}
function escapeHtml(text) {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}
function editMarkdown(doc, action, text) {
  let newMarkdown;
  if (action === "replace") {
    newMarkdown = text;
  } else {
    newMarkdown = doc + text;
  }
  const result = renderMarkdown(newMarkdown);
  return {
    markdown: newMarkdown,
    html: result.html
  };
}
var operations = {
  render: async (input) => {
    const res = renderMarkdown(input.markdown);
    return { html: res.html };
  },
  edit: async (input) => {
    const res = editMarkdown(input.doc, input.action, input.text);
    return { markdown: res.markdown, html: res.html };
  }
};
var index_default = operations;

// __splice_entry.ts
var defaultObject = index_default && typeof index_default === "object" ? index_default : {};
var operations2 = {
  ["render"]: async (input, ctx) => {
    const table = operations ?? defaultObject.operations ?? index_default;
    const fn = table?.["render"] ?? void 0;
    if (typeof fn !== "function") throw new Error("missing operation render");
    return await fn(input, ctx);
  },
  ["edit"]: async (input, ctx) => {
    const table = operations ?? defaultObject.operations ?? index_default;
    const fn = table?.["edit"] ?? void 0;
    if (typeof fn !== "function") throw new Error("missing operation edit");
    return await fn(input, ctx);
  }
};
export {
  operations2 as operations
};
