
// Interfaces
export interface RenderResult {
  html: string;
}

export interface EditResult {
  markdown: string;
  html: string;
}

// Renderer function
export function renderMarkdown(markdown: string): RenderResult {
  // Split the markdown into lines
  const lines = markdown.split('\n');
  let html = '';
  let i = 0;
  
  // Process each line
  while (i < lines.length) {
    const line = lines[i];
    
    // Check for different markdown elements
    if (line.startsWith('#')) {
      // Headings
      const headingMatch = line.match(/^(#{1,6})\s+(.*)$/);
      if (headingMatch) {
        const level = headingMatch[1].length;
        const content = headingMatch[2];
        html += `<h${level}>${formatInline(content)}</h${level}>\n`;
        i++;
        continue;
      }
    } else if (line.startsWith('```')) {
      // Code blocks
      const langMatch = line.match(/^```(\w*)/);
      const lang = langMatch ? langMatch[1] : '';
      i++;
      
      let codeContent = '';
      while (i < lines.length && !lines[i].startsWith('```')) {
        codeContent += lines[i] + '\n';
        i++;
      }
      i++; // Skip closing ```
      
      html += `<pre><code class="${lang ? `language-${lang}` : ''}">${escapeHtml(codeContent.trim())}</code></pre>\n`;
      continue;
    } else if (line.startsWith('> ')) {
      // Callouts
      if (line.includes('[!')) {
        const calloutMatch = line.match(/> \[!(\w+)\]/);
        const calloutType = calloutMatch ? calloutMatch[1].toLowerCase() : 'note';
        i++;
        
        let calloutContent = '';
        while (i < lines.length && lines[i].startsWith('> ')) {
          calloutContent += lines[i].substring(2) + '\n';
          i++;
        }
        
        html += `<div class="callout" data-callout="${calloutType}">${formatInline(calloutContent.trim())}</div>\n`;
        continue;
      } else {
        // Regular blockquote
        let quoteContent = '';
        while (i < lines.length && lines[i].startsWith('> ')) {
          quoteContent += lines[i].substring(2) + '\n';
          i++;
        }
        html += `<blockquote>${formatInline(quoteContent.trim())}</blockquote>\n`;
        continue;
      }
    } else if (line.startsWith('- ') || line.startsWith('* ')) {
      // Unordered lists
      const listItems: { content: string; level: number }[] = [];
      
      while (i < lines.length && (lines[i].startsWith('- ') || lines[i].startsWith('* ') || lines[i].startsWith('  '))) {
        const listItemLine = lines[i];
        const indentLevel = Math.floor((listItemLine.search(/\S/) || 0) / 2);
        const content = listItemLine.trim().substring(2);
        listItems.push({ content, level: indentLevel });
        i++;
      }
      
      html += renderList(listItems);
      continue;
    } else if (/^\|(.+\|)+$/.test(line)) {
      // Tables
      const tableLines = [];
      while (i < lines.length && lines[i].trim() !== '') {
        tableLines.push(lines[i]);
        i++;
      }
      
      html += renderTable(tableLines);
      continue;
    } else if (line.trim() === '') {
      // Empty lines
      i++;
      continue;
    } else {
      // Regular paragraph
      let paragraphContent = line;
      i++;
      
      // Handle multiline paragraphs
      while (i < lines.length && lines[i].trim() !== '' && 
             !lines[i].startsWith('#') && 
             !lines[i].startsWith('```') && 
             !lines[i].startsWith('> ') && 
             !lines[i].startsWith('- ') && 
             !lines[i].startsWith('* ') &&
             !/^\|(.+\|)+$/.test(lines[i])) {
        paragraphContent += ' ' + lines[i];
        i++;
      }
      
      html += `<p>${formatInline(paragraphContent)}</p>\n`;
      continue;
    }
    
    // Default case for unprocessed lines
    if (line.trim() !== '') {
      html += `<p>${formatInline(line)}</p>\n`;
    }
    i++;
  }
  
  return { html: html.trim() };
}

// Helper function to render lists
function renderList(items: { content: string; level: number }[]): string {
  if (items.length === 0) return '';
  
  let html = '';
  let currentLevel = -1;
  
  items.forEach((item, index) => {
    // Open/close tags based on level changes
    if (item.level > currentLevel) {
      // Need to open new levels
      for (let i = currentLevel; i < item.level; i++) {
        html += '<ul>\n';
      }
    } else if (item.level < currentLevel) {
      // Need to close levels
      for (let i = currentLevel; i > item.level; i--) {
        html += '</li>\n</ul>\n';
      }
    } else if (index > 0) {
      // Same level, close previous item
      html += '</li>\n';
    }
    
    // Add the list item content
    html += `<li>${formatInline(item.content)}`;
    currentLevel = item.level;
  });
  
  // Close all remaining tags
  for (let i = currentLevel; i >= 0; i--) {
    if (i === currentLevel) {
      html += '</li>\n';
    }
    html += '</ul>\n';
  }
  
  return html;
}

// Helper function to render tables
function renderTable(lines: string[]): string {
  if (lines.length < 2) return '';
  
  const headers = lines[0].split('|').map(cell => cell.trim()).filter(cell => cell.length > 0);
  // Skip separator line (lines[1])
  
  let html = '<table>\n<thead>\n<tr>\n';
  headers.forEach(header => {
    html += `<th>${formatInline(header)}</th>\n`;
  });
  html += '</tr>\n</thead>\n<tbody>\n';
  
  // Process body rows (skip header and separator)
  for (let i = 2; i < lines.length; i++) {
    const cells = lines[i].split('|').map(cell => cell.trim()).filter(cell => cell.length > 0);
    if (cells.length > 0) {
      html += '<tr>\n';
      cells.forEach(cell => {
        html += `<td>${formatInline(cell)}</td>\n`;
      });
      html += '</tr>\n';
    }
  }
  
  html += '</tbody>\n</table>\n';
  return html;
}

// Helper function to format inline elements
function formatInline(text: string): string {
  if (!text) return '';
  
  // Process internal links first [[link]]
  text = text.replace(/\[\[(.*?)\]\]/g, '<a class="internal-link" data-href="$1" href="$1">$1</a>');
  
  // Process external links [text](url)
  text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a class="external-link" href="$2" rel="noopener nofollow">$1</a>');
  
  // Process strikethrough ~~text~~
  text = text.replace(/~~(.*?)~~/g, '<del>$1</del>');
  
  // Process bold **text** or __text__
  text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  text = text.replace(/__(.*?)__/g, '<strong>$1</strong>');
  
  // Process italic *text* or _text_
  text = text.replace(/(?<!\*)\*(?!\*)(.*?)\*(?!\*)/g, '<em>$1</em>');
  text = text.replace(/(?<!_)_(?!_)(.*?)_(?!_)/g, '<em>$1</em>');
  
  return text;
}

// Helper function to escape HTML characters
function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// Editor function
export function editMarkdown(doc: string, action: "replace" | "append", text: string): EditResult {
  let newMarkdown: string;
  
  if (action === "replace") {
    newMarkdown = text;
  } else {
    newMarkdown = doc + text;
  }
  
  const result = renderMarkdown(newMarkdown);
  return {
    markdown: newMarkdown,
    html: result.html
  };
}

export const operations = {
  render: async (input: { markdown: string }) => {
    const res = renderMarkdown(input.markdown);
    return { html: res.html };
  },
  edit: async (input: { doc: string; action: "replace" | "append"; text: string }) => {
    const res = editMarkdown(input.doc, input.action, input.text);
    return { markdown: res.markdown, html: res.html };
  }
};
export default operations;
