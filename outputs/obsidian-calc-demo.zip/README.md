# Obsidian Notes with LibreOffice Calc Tables

Linux x64 source export. Requires Node 22+, bubblewrap, prlimit and Electron 45.0.0.
Run `npm install` followed by `npm start`. Capability processes run with read-only package mounts and no network namespace access.
