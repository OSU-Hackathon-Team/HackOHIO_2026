
const descriptor = {"title":"Obsidian Notes with LibreOffice Calc Tables","description":"Interactive Obsidian-rendered Markdown notes with integrated LibreOffice Calc formula evaluation and table operations.","surfaces":[{"id":"obsidian_editor_view","kind":"document","title":"Obsidian Markdown Editor & Viewer","bindings":[{"name":"markdown","source":"$doc.note.markdown","operation":null},{"name":"html","source":"$doc.note.html","operation":null},{"name":"formula","source":"$doc.note.formula","operation":null},{"name":"formula_value","source":"$doc.note.formula_value","operation":null}],"actions":[{"id":"update","label":"Render and Evaluate","workflow":"render_and_eval"},{"id":"edit","label":"Edit Markdown","workflow":"edit_markdown"}]},{"id":"calc_table_view","kind":"table","title":"LibreOffice Calc Table","bindings":[{"name":"grid","source":"$doc.table.grid","operation":null},{"name":"numeric_cells","source":"$doc.table.numeric_cells","operation":null}],"actions":[{"id":"sort","label":"Table Operation","workflow":"apply_table_op"}]}],"workflows":[{"id":"render_and_eval","name":"Update Note and Evaluate Formula","sample":{"formula":"=B2*C2","markdown":"# Budget Plan\n\nTotal is **100**."}},{"id":"apply_table_op","name":"Execute LibreOffice Calc Table Operation","sample":{"operation":{"type":"sort_range","range":"A1:B4","keys":[{"column":0,"ascending":true}],"contains_header":true}}},{"id":"edit_markdown","name":"Edit Obsidian Markdown Document","sample":{"action":"append","text":"\n\n> [!NOTE]\n> Next section"}}],"providers":[]};
const root = document.getElementById("app");
root.replaceChildren();
const title = document.createElement("h1"); title.textContent = descriptor.title; root.append(title);
const description = document.createElement("p"); description.textContent = descriptor.description; root.append(description);
const workflowInputs = new Map();
const surfaceRefreshers = [];
for (const workflow of descriptor.workflows) {
  const section = document.createElement("section");
  const heading = document.createElement("h2"); heading.textContent = workflow.name; section.append(heading);
  const input = document.createElement("textarea"); input.setAttribute("aria-label", workflow.name + " input JSON"); input.value = JSON.stringify(workflow.sample, null, 2); section.append(input);
  workflowInputs.set(workflow.id, input);
  const button = document.createElement("button"); button.type = "button"; button.textContent = "Run workflow"; section.append(button);
  const output = document.createElement("pre"); output.setAttribute("aria-live", "polite"); section.append(output);
  button.addEventListener("click", async () => {
    button.disabled = true; output.textContent = "Running…";
    try { const result = await window.splice.runWorkflow(workflow.id, JSON.parse(input.value)); output.textContent = JSON.stringify(result, null, 2); await Promise.allSettled(surfaceRefreshers.map((refresh) => refresh())); }
    catch (error) { output.textContent = error instanceof Error ? error.message : String(error); }
    finally { button.disabled = false; }
  });
  root.append(section);
}
for (const surface of descriptor.surfaces) {
  const source = surface.bindings.find((binding) => binding.source.startsWith("$doc."))?.source;
  if (!source) continue;
  const documentId = source.split(".")[1];
  const section = document.createElement("section");
  const heading = document.createElement("h2"); heading.textContent = surface.title; section.append(heading);
  const body = document.createElement("div"); section.append(body);
  const status = document.createElement("pre"); status.setAttribute("aria-live", "polite"); section.append(status);
  root.append(section);
  let snapshot = null;
  async function refresh() {
    snapshot = await window.splice.getDocument(documentId);
    body.replaceChildren();
    if (surface.kind !== "table" || !source.endsWith(".cells")) {
      const display = document.createElement("pre"); display.textContent = JSON.stringify(snapshot?.data ?? null, null, 2); body.append(display);
      return;
    }
    const table = document.createElement("table");
    const header = document.createElement("tr");
    for (const label of ["Cell", "Confirmed value", ""]) { const th = document.createElement("th"); th.textContent = label; header.append(th); }
    table.append(header);
    function addRow(cell, value) {
      const row = document.createElement("tr");
      const nameCell = document.createElement("td"); const name = document.createElement("input"); name.type = "text"; name.value = cell; name.setAttribute("aria-label", "Cell name"); nameCell.append(name);
      const valueCell = document.createElement("td"); const amount = document.createElement("input"); amount.type = "number"; amount.step = "any"; amount.value = String(value); amount.setAttribute("aria-label", "Value for " + cell); valueCell.append(amount);
      const removeCell = document.createElement("td"); const remove = document.createElement("button"); remove.type = "button"; remove.textContent = "Remove"; remove.addEventListener("click", () => row.remove()); removeCell.append(remove);
      row.append(nameCell, valueCell, removeCell); table.append(row);
    }
    for (const [cell, value] of Object.entries(snapshot?.data?.cells ?? {}).sort()) addRow(cell, value);
    body.append(table);
    const add = document.createElement("button"); add.type = "button"; add.textContent = "Add cell"; add.addEventListener("click", () => addRow("", "")); body.append(add);
    const save = document.createElement("button"); save.type = "button"; save.textContent = "Save confirmed cells"; body.append(save);
    save.addEventListener("click", async () => {
      save.disabled = true;
      try {
        const cells = {};
        for (const row of [...table.querySelectorAll("tr")].slice(1)) {
          const [name, amount] = row.querySelectorAll("input");
          const cell = name.value.trim().toUpperCase();
          if (!/^[A-Z]{1,3}[1-9][0-9]{0,6}$/.test(cell) || amount.value.trim() === "" || !Number.isFinite(Number(amount.value)) || Object.hasOwn(cells, cell)) throw new Error("Enter a unique A1-style cell and a finite number for each row");
          cells[cell] = Number(amount.value);
        }
        snapshot = await window.splice.saveDocument(documentId, { cells }, snapshot?.revision ?? null);
        status.textContent = "Confirmed cells saved (revision " + snapshot.revision + ")";
        await refresh();
      } catch (error) { status.textContent = error instanceof Error ? error.message : String(error); }
      finally { save.disabled = false; }
    });
  }
  surfaceRefreshers.push(refresh);
  void refresh().catch((error) => { status.textContent = error instanceof Error ? error.message : String(error); });
}
for (const provider of descriptor.providers) {
  const section = document.createElement("section");
  const heading = document.createElement("h2"); heading.textContent = "Transcription"; section.append(heading);
  const explanation = document.createElement("p"); explanation.textContent = "Import a mono PCM16 WAV to transcribe it into " + provider.document + ". The external provider needs credentials in the application environment."; section.append(explanation);
  const file = document.createElement("input"); file.type = "file"; file.accept = ".wav,audio/wav"; file.setAttribute("aria-label", "Audio WAV file"); section.append(file);
  const language = document.createElement("input"); language.type = "text"; language.value = "en-US"; language.setAttribute("aria-label", "Transcription language"); section.append(language);
  const start = document.createElement("button"); start.type = "button"; start.textContent = "Transcribe WAV"; section.append(start);
  const cancel = document.createElement("button"); cancel.type = "button"; cancel.textContent = "Cancel transcription"; cancel.disabled = true; section.append(cancel);
  const status = document.createElement("pre"); status.setAttribute("aria-live", "polite"); section.append(status);
  root.append(section);
  let currentSession = null;
  let appliedSession = null;
  let configured = false;
  function display(session) {
    if (session?.projection?.provider_id !== provider.id) return;
    currentSession = session;
    cancel.disabled = session.status !== "queued" && session.status !== "running";
    start.disabled = !configured || !cancel.disabled;
    status.textContent = "Transcription " + session.status + " (attempt " + session.attempt + ")" +
      (session.error ? "\n" + session.error : "") +
      "\n" + session.segments.map((item) => "[" + item.start_ms + "-" + item.end_ms + " ms] " + item.text + (item.final ? "" : " …")).join("\n");
    if (session.status === "succeeded" && provider.workflow_input && appliedSession !== session.session_id) {
      const workflowInput = workflowInputs.get(provider.workflow_input.workflow);
      if (workflowInput) {
        try {
          const value = JSON.parse(workflowInput.value);
          const parts = provider.workflow_input.path.split(".");
          let target = value;
          for (const part of parts.slice(0, -1)) target = target[part] ??= {};
          target[parts.at(-1)] = session.segments.map((item) => ({ id: session.projection.id_prefix + "-" + item.index, start_ms: item.start_ms, end_ms: item.end_ms, text: item.text }));
          workflowInput.value = JSON.stringify(value, null, 2);
          appliedSession = session.session_id;
        } catch (error) { status.textContent += "\nCould not update workflow input: " + String(error); }
      }
    }
  }
  window.splice.onTranscription(display);
  void (async () => {
    try {
      const availability = await window.splice.transcriptionAvailability();
      configured = availability.configured;
      start.disabled = !configured;
      if (!configured) status.textContent = availability.detail;
      const sessions = await window.splice.listTranscriptions();
      const recent = sessions.find((item) => item.projection?.provider_id === provider.id);
      if (recent) display(recent);
    } catch (error) { status.textContent = String(error); }
  })();
  start.addEventListener("click", async () => {
    const selected = file.files?.[0];
    if (!selected) { status.textContent = "Choose a WAV file first"; return; }
    start.disabled = true; status.textContent = "Saving audio…";
    try {
      const session = await window.splice.startTranscription(new Uint8Array(await selected.arrayBuffer()), provider.id, language.value);
      display(session);
    } catch (error) { status.textContent = error instanceof Error ? error.message : String(error); }
    finally { start.disabled = !configured || (currentSession && (currentSession.status === "queued" || currentSession.status === "running")); }
  });
  cancel.addEventListener("click", async () => {
    if (!currentSession) return;
    try { display(await window.splice.cancelTranscription(currentSession.session_id)); }
    catch (error) { status.textContent = error instanceof Error ? error.message : String(error); }
  });
}
