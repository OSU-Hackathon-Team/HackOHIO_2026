// index.ts
function renderMarkdown(markdown) {
  const lines = markdown.split("\n");
  const processedLines = [];
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (line.startsWith("```")) {
      const result = processCodeBlock(lines, i);
      processedLines.push(result.html);
      i = result.nextIndex;
      continue;
    }
    if (line.match(/^#{1,6}\s/)) {
      processedLines.push(processHeading(line));
      i++;
      continue;
    }
    if (line.startsWith(">")) {
      const result = processBlockquote(lines, i);
      processedLines.push(result.html);
      i = result.nextIndex;
      continue;
    }
    if (line.match(/^\s*[-*]\s/)) {
      const result = processList(lines, i);
      processedLines.push(result.html);
      i = result.nextIndex;
      continue;
    }
    if (line.startsWith("|")) {
      const result = processTable(lines, i);
      processedLines.push(result.html);
      i = result.nextIndex;
      continue;
    }
    processedLines.push(line);
    i++;
  }
  let html = processedLines.join("\n");
  html = processInlineFormatting(html);
  html = processLinks(html);
  html = processParagraphs(html);
  return { html };
}
function editMarkdown(doc, action, text) {
  const markdown = action === "replace" ? text : doc + text;
  const rendered = renderMarkdown(markdown);
  return {
    markdown,
    html: rendered.html
  };
}
function escapeHtml(text) {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}
function processCodeBlock(lines, startIndex) {
  const startLine = lines[startIndex];
  const lang = startLine.substring(3).trim();
  const contentLines = [];
  let i = startIndex + 1;
  while (i < lines.length && !lines[i].startsWith("```")) {
    contentLines.push(lines[i]);
    i++;
  }
  const languageClass = lang ? ` class="language-${lang}"` : "";
  const escapedContent = escapeHtml(contentLines.join("\n"));
  return {
    html: `<pre><code${languageClass}>${escapedContent}</code></pre>`,
    nextIndex: i + 1
  };
}
function processHeading(line) {
  const match = line.match(/^(#{1,6})\s+(.*?)\s*$/);
  if (!match) return line;
  const level = match[1].length;
  const content = match[2];
  return `<h${level} data-heading="${content}">${content}</h${level}>`;
}
function processBlockquote(lines, startIndex) {
  const blockquoteLines = [];
  let i = startIndex;
  while (i < lines.length && lines[i].startsWith(">")) {
    const line = lines[i];
    const calloutMatch = line.match(/^>\s*\[!(\w+)\]\s*(.*)/);
    if (calloutMatch) {
      const calloutType = calloutMatch[1].toLowerCase();
      const content = calloutMatch[2] || "";
      i++;
      const contentLines = [content];
      while (i < lines.length && lines[i].startsWith(">")) {
        contentLines.push(lines[i].substring(1).trim());
        i++;
      }
      const contentHtml = contentLines.filter((l) => l !== "").join("<br>");
      return {
        html: `<div class="callout" data-callout="${calloutType}">${contentHtml}</div>`,
        nextIndex: i
      };
    }
    blockquoteLines.push(line.substring(1).trimStart());
    i++;
  }
  const processedContent = blockquoteLines.map((line) => processInlineFormatting(processLinks(line))).join("<br>");
  return {
    html: `<blockquote>${processedContent}</blockquote>`,
    nextIndex: i
  };
}
function processList(lines, startIndex) {
  const listItems = [];
  let i = startIndex;
  while (i < lines.length && (lines[i].match(/^\s*[-*]\s/) || lines[i].match(/^\s*$/))) {
    const match = lines[i].match(/^(\s*)[-*]\s(.*)/);
    if (match) {
      const indent = match[1].length;
      const content = match[2];
      listItems.push({ content, indent });
    }
    i++;
  }
  const html = buildNestedList(listItems, 0);
  return {
    html: `<ul>${html}</ul>`,
    nextIndex: i
  };
}
function buildNestedList(items, baseIndent) {
  let html = "";
  let i = 0;
  while (i < items.length) {
    const item = items[i];
    if (item.indent < baseIndent) {
      break;
    }
    if (item.indent > baseIndent) {
      const nestedItems = [];
      let j = i;
      while (j < items.length && items[j].indent >= item.indent) {
        nestedItems.push(items[j]);
        j++;
      }
      const nestedHtml = buildNestedList(nestedItems, item.indent);
      html = html.slice(0, -5);
      html += `<ul>${nestedHtml}</ul></li>`;
      i = j;
      continue;
    }
    const processedContent = processInlineFormatting(processLinks(item.content));
    html += `<li>${processedContent}</li>`;
    i++;
  }
  return html;
}
function processTable(lines, startIndex) {
  const tableLines = [];
  let i = startIndex;
  while (i < lines.length && (lines[i].startsWith("|") || lines[i].match(/^[\s|:-]+$/))) {
    tableLines.push(lines[i]);
    i++;
  }
  if (tableLines.length < 2) {
    return {
      html: tableLines.join("\n"),
      nextIndex: i
    };
  }
  const headers = tableLines[0].split("|").slice(1, -1).map((cell) => cell.trim());
  const alignments = [];
  if (tableLines[1]) {
    const separators = tableLines[1].split("|").slice(1, -1).map((s) => s.trim());
    separators.forEach((separator) => {
      if (separator.startsWith(":") && separator.endsWith(":")) {
        alignments.push("center");
      } else if (separator.endsWith(":")) {
        alignments.push("right");
      } else {
        alignments.push("left");
      }
    });
  }
  const rows = [];
  for (let j = 2; j < tableLines.length; j++) {
    if (tableLines[j].startsWith("|")) {
      const cells = tableLines[j].split("|").slice(1, -1).map((cell) => cell.trim());
      rows.push(cells);
    }
  }
  let html = '<table class="table-editor"><thead><tr>';
  for (let j = 0; j < headers.length; j++) {
    const align = alignments[j] || "left";
    html += `<th style="text-align: ${align}">${headers[j]}</th>`;
  }
  html += "</tr></thead><tbody>";
  for (const row of rows) {
    html += "<tr>";
    for (let j = 0; j < headers.length; j++) {
      const cell = row[j] || "";
      const align = alignments[j] || "left";
      html += `<td style="text-align: ${align}">${cell}</td>`;
    }
    html += "</tr>";
  }
  html += "</tbody></table>";
  return {
    html,
    nextIndex: i
  };
}
function processInlineFormatting(text) {
  text = text.replace(/~~(.*?)~~/g, "<del>$1</del>");
  text = text.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
  text = text.replace(/__(.*?)__/g, "<strong>$1</strong>");
  text = text.replace(/(?<!\*)\*([^*]+)\*(?!\*)/g, "<em>$1</em>");
  text = text.replace(/(?<!_)_([^_]+)_(?!_)/g, "<em>$1</em>");
  return text;
}
function processLinks(text) {
  text = text.replace(
    /\[([^\]]+)\]\(([^)]+)\)/g,
    '<a class="external-link" href="$2" rel="noopener nofollow">$1</a>'
  );
  text = text.replace(
    /\[\[([^\]]+)\]\]/g,
    '<a class="internal-link is-unresolved" href="$1" rel="noopener nofollow" data-href="$1">$1</a>'
  );
  return text;
}
function processParagraphs(html) {
  const blocks = html.split("\n\n");
  const processedBlocks = blocks.map((block) => {
    if (block.startsWith("<") || block === "") {
      return block;
    }
    if (block.trim() !== "") {
      return `<p>${block}</p>`;
    }
    return block;
  });
  return processedBlocks.join("\n\n");
}
var operations = {
  render: async (input) => {
    const res = renderMarkdown(input.markdown);
    return { html: res.html };
  },
  edit: async (input) => {
    const res = editMarkdown(input.doc, input.action, input.text);
    return { markdown: res.markdown, html: res.html };
  }
};
var index_default = operations;

// __splice_entry.ts
var defaultObject = index_default && typeof index_default === "object" ? index_default : {};
var operations2 = {
  ["render"]: async (input, ctx) => {
    const table = operations ?? defaultObject.operations ?? index_default;
    const fn = table?.["render"] ?? void 0;
    if (typeof fn !== "function") throw new Error("missing operation render");
    return await fn(input, ctx);
  },
  ["edit"]: async (input, ctx) => {
    const table = operations ?? defaultObject.operations ?? index_default;
    const fn = table?.["edit"] ?? void 0;
    if (typeof fn !== "function") throw new Error("missing operation edit");
    return await fn(input, ctx);
  }
};
export {
  operations2 as operations
};
